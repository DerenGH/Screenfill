package com.deren.screenfill;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_VERTICAL);

        TextView info = new TextView(this);
        info.setTextSize(16);
        info.setText(
                "Screen Fill\n\n"
                + "1. Tap the button below and turn on \"Screen Fill\" in Accessibility.\n"
                + "2. Open the app you're testing.\n"
                + "3. Tap the floating \"Fill\" button. It finds the paragraph above the "
                + "input box, copies it to the clipboard and types it into the box.\n\n"
                + "Drag the button to move it.");
        root.addView(info);

        Button open = new Button(this);
        open.setText("Open Accessibility settings");
        open.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(open);

        setContentView(root);
    }
}
