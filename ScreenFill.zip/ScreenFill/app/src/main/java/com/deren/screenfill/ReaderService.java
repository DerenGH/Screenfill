package com.deren.screenfill;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Shows a small floating "Fill" button over every app. When tapped it reads the
 * screen, finds the input box and the longest text above it, copies that text
 * to the clipboard and puts it into the box.
 */
public class ReaderService extends AccessibilityService {

    private WindowManager wm;
    private TextView button;
    private WindowManager.LayoutParams lp;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Nothing to do: we only act when the floating button is tapped.
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        addButton();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        removeButton();
        return super.onUnbind(intent);
    }

    private void addButton() {
        if (button != null) return;
        float d = getResources().getDisplayMetrics().density;
        int size = (int) (56 * d);

        button = new TextView(this);
        button.setText("Fill");
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xFF5B6CF5);
        button.setBackground(bg);

        lp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (16 * d);
        lp.y = (int) (300 * d);

        button.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        if (moved) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            wm.updateViewLayout(button, lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) runFill();
                        return true;
                    default:
                        return false;
                }
            }
        });

        wm.addView(button, lp);
    }

    private void removeButton() {
        if (button != null && wm != null) {
            try {
                wm.removeView(button);
            } catch (Exception ignored) {
            }
        }
        button = null;
    }

    private void runFill() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            toast("Can't read the screen");
            return;
        }

        List<AccessibilityNodeInfo> edits = new ArrayList<>();
        List<AccessibilityNodeInfo> texts = new ArrayList<>();
        collect(root, edits, texts);

        AccessibilityNodeInfo edit = pickEdit(edits);
        String text = pickText(texts, edit);
        if (text == null) {
            toast("No text found");
            return;
        }

        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("screenfill", text));

        if (edit == null) {
            toast("Copied (no input box found)");
            return;
        }

        edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        boolean ok = edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        if (!ok) {
            ok = edit.performAction(AccessibilityNodeInfo.ACTION_PASTE);
        }
        toast(ok ? "Filled" : "Copied, but couldn't fill the box");
    }

    private void collect(AccessibilityNodeInfo n,
                         List<AccessibilityNodeInfo> edits,
                         List<AccessibilityNodeInfo> texts) {
        if (n == null || !n.isVisibleToUser()) return;
        if (n.isEditable()) {
            edits.add(n);
        } else {
            CharSequence t = n.getText();
            if (t != null && t.toString().trim().length() > 0) texts.add(n);
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            collect(n.getChild(i), edits, texts);
        }
    }

    /** The topmost input box on screen. */
    private AccessibilityNodeInfo pickEdit(List<AccessibilityNodeInfo> edits) {
        AccessibilityNodeInfo best = null;
        int bestTop = Integer.MAX_VALUE;
        Rect r = new Rect();
        for (AccessibilityNodeInfo e : edits) {
            e.getBoundsInScreen(r);
            if (r.top < bestTop) {
                bestTop = r.top;
                best = e;
            }
        }
        return best;
    }

    /** The longest text above the input box (or on the whole screen if there is no box). */
    private String pickText(List<AccessibilityNodeInfo> texts, AccessibilityNodeInfo edit) {
        int limit = Integer.MAX_VALUE;
        if (edit != null) {
            Rect er = new Rect();
            edit.getBoundsInScreen(er);
            limit = er.top + 5;
        }
        String best = null;
        Rect r = new Rect();
        for (AccessibilityNodeInfo n : texts) {
            n.getBoundsInScreen(r);
            if (r.bottom > limit) continue;
            String t = n.getText().toString().trim();
            if (best == null || t.length() > best.length()) best = t;
        }
        return best;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
